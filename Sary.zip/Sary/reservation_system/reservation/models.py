from django.db import models
from django.utils.translation import gettext as _
from django.contrib.auth.models import User
from django.urls import reverse


class Staff_Member(models.Model):
    # Staff Members roles
    class Roles:
        Employee = 'Employee'
        Admin = 'Admin'

        @classmethod
        def choices(cls):
            return(
                (cls.Employee, _('Employee')),
                (cls.Admin, _('Admin')),
            )

    first_name = models.CharField(max_length=30, null=False)
    last_name = models.CharField(max_length=30, null=False)
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    id_number = models.IntegerField(null=False, unique=True)
    role = models.CharField(max_length=20, null=False, choices=Roles.choices())

    def __str__(self):
        return self.first_name + '\'s ' + self.last_name


class Table(models.Model):
    created_by = models.ForeignKey(Staff_Member, on_delete=models.CASCADE)
    table_number = models.PositiveSmallIntegerField(null=False, blank=False, unique=True)
    number_of_seats = models.PositiveIntegerField(null=False, blank=False, unique=False)

    def get_absolute_url(self):
        return reverse('get_restaurant_tables')



class Reservation(models.Model):
    start_time = models.TimeField(auto_now=False, auto_now_add=False)
    end_time = models.TimeField(auto_now=False, auto_now_add=False)
    date = models.DateField(null=True)
    employee = models.ForeignKey(Staff_Member, null=True, on_delete=models.SET_NULL)
    table = models.ForeignKey(Table, null=True, on_delete=models.SET_NULL)
    client_name = models.CharField(max_length=100, null=False)
    client_phone = models.CharField(max_length=100, null=False)

    class Meta:
        unique_together = ('start_time', 'date', 'table')

    def get_absolute_url(self):
        return reverse('get_reservations_for_today')

    def __str__(self):
        return 'Client:'+self.client_name + '\' ph:' + self.client_phone