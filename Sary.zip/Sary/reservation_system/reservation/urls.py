from django.contrib.auth import views as auth_views
from django.urls import path
from . import views
from .views import *

urlpatterns = [
    path('', views.home, name='home'),
    path('get-restaurant-tables/', views.get_restaurant_tables, name='get_restaurant_tables'),
    path('get-all-reservations/', views.get_all_reservations, name='get_all_reservations'),
    path('reservation/<int:pk>/delete/', ReservationDeleteView.as_view(), name='reservation_delete'),
    path('table/<int:pk>/delete/', TableDeleteView.as_view(), name='table_delete'),
    path('available_time_slots/<reservation_day>/<table_id>/', views.available_time_slots, name='available_time_slots'),
    path('table/new/', TableCreateView.as_view(), name='add_table'),
    path('reservation/new/<reservation_day>/<table_id>/<start_time>/<end_time>/', ReservationCreateView.as_view(), name='add_reservation'),
    path('get-reservations-for-today/', views.get_reservations_for_today, name='get_reservations_for_today'),
    path('new_reservation/', views.new_reservation, name='new_reservation'),
    path('new_reservation/new_reservation_available_tables/', views.new_reservation_available_tables, name='new_reservation_available_tables'),
    path('login', auth_views.LoginView.as_view(template_name='reservation/login.html'), name='login'),
    path('logout/', auth_views.LogoutView.as_view(template_name='reservation/logout.html'), name='logout'),

]