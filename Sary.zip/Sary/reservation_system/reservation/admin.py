from django.contrib import admin
from .models import *

admin.site.register(Staff_Member)
admin.site.register(Table)
admin.site.register(Reservation)
