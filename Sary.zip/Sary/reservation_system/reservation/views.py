from django.shortcuts import render, redirect
from django.contrib.auth.decorators import login_required
from django.views.generic import *
from reservation.models import *
from datetime import date, datetime, time, timedelta
from django.contrib import messages
from django.urls import reverse
from django.contrib.auth.mixins import LoginRequiredMixin, UserPassesTestMixin
from django.db.models import Max


# Home Page View
@login_required
def home(request):

    # get user info
    staff_member = Staff_Member.objects.filter(user=request.user).first()

    context = {
        "staff_member": staff_member
    }

    return render(request, 'reservation/home.html', context)


# Restaurant tables View
@login_required
def get_restaurant_tables(request):
    # get user info
    staff_member = Staff_Member.objects.filter(user=request.user).first()

    # redirect unauthorized users to home page
    if staff_member.role == 'Admin':

        # get all upcoming reservations (to disable deleting the reserved tables)
        today = date.today()
        now = datetime.now().time()
        reservations_for_today = Reservation.objects.filter(date=today, start_time__gte=now)
        reservations_for_upcoming_days = Reservation.objects.filter(date__gt=today)
        reservations = reservations_for_today.union(reservations_for_upcoming_days)

        # get all reserved tables to disable its deletion button in the frontend
        reserved_tables = []
        for reservation in reservations:
            if reservation.table not in reserved_tables:
                reserved_tables.append(reservation.table)

        # get all restaurant tables
        tables = Table.objects.all().order_by('table_number')

        context = {
            "staff_member": staff_member,
            "tables": tables,
            "reserved_tables": reserved_tables
        }

        return render(request, 'reservation/get_restaurant_tables.html', context)
    else:
        return redirect(home)


# All Reservations View
@login_required
def get_all_reservations(request):

    # get user info
    staff_member = Staff_Member.objects.filter(user=request.user).first()

    # redirect unauthorized users to home page
    if staff_member.role == 'Admin':

        # get all reservations
        reservations = Reservation.objects.all().order_by('-date', 'start_time', 'end_time')

        context = {
            "staff_member": staff_member,
            "reservations": reservations
        }

        return render(request, 'reservation/get_all_reservations.html', context)
    else:
        return redirect(home)


# Today's Reservations View
@login_required
def get_reservations_for_today(request):

    # get user info
    staff_member = Staff_Member.objects.filter(user=request.user).first()

    # get today's reservations
    today = date.today()
    now = datetime.now().time()
    reservations = Reservation.objects.all().filter(date=today).order_by('start_time', 'end_time')

    context = {
        "staff_member": staff_member,
        "reservations": reservations,
        "today": today,
        "now": now
    }

    return render(request, 'reservation/get_reservations_for_today.html', context)


# Delete a Reservation Class
class ReservationDeleteView(LoginRequiredMixin, UserPassesTestMixin, DeleteView):
    model = Reservation
    delete_message = 'Deleted successfully'

    def get_success_url(self):
        return reverse('get_reservations_for_today')

    # check if that it is an upcoming reservation not an old one
    def test_func(self):
        today = date.today()
        now = datetime.now().time()
        reservation = self.get_object()

        if reservation.date == today:
            if reservation.start_time >= now:
                return True
        return False


# Add restaurant table view
class TableCreateView(LoginRequiredMixin, CreateView):
    model = Table
    fields = ['table_number', 'number_of_seats']

    def form_valid(self, form):
        form.instance.created_by = Staff_Member.objects.filter(user=self.request.user).first()
        return super().form_valid(form)


# Delete a restaurant table view
class TableDeleteView(LoginRequiredMixin, UserPassesTestMixin, DeleteView):
    model = Table
    delete_message = 'Deleted successfully'

    def get_success_url(self):
        return reverse('get_restaurant_tables')

    # Check if the table is reserved for an upcoming reservations before deletion
    def test_func(self):
        today = date.today()
        now = datetime.now().time()
        reservations_per_table = Reservation.objects.filter(table=self.get_object())

        for reservation in reservations_per_table:
            if reservation.date > today:
                return False
            if reservation.date == today:
                if reservation.start_time >= now:
                    return False
        return True


@login_required
def new_reservation(request):
    staff_member = Staff_Member.objects.filter(user=request.user).first()
    max_size = Table.objects.aggregate(Max('number_of_seats'))
    today = date.today().strftime('%Y-%m-%d')
    context = {
        "staff_member": staff_member,
        "max_size": max_size,
        "today": today
    }
    return render(request, 'reservation/new_reservation.html', context)


@login_required
def new_reservation_available_tables(request):
    # a post request is received, other wise the user will be redirected to "get_time_slots" view
    if request.method == 'POST':
        staff_member = Staff_Member.objects.filter(user=request.user).first()

        required_number_of_seats = request.POST['required_number_of_seats']
        reservation_day = request.POST['reservation_day']

        # find the nearest number of seats which is >= the required seats
        # tables are ordered by number of seats to make sure we find the nearest number of seats
        exist_number_of_seats = 0
        tables = Table.objects.all().order_by('number_of_seats')
        for table in tables:
            if table.number_of_seats >= int(required_number_of_seats):
                exist_number_of_seats = table.number_of_seats
                break

        # if real seat > 0, it means there is an available table with required number of seats
        # otherwise the reservation will not be allowed and the user will be redirected to "get_time_slots" view
        # however, we do not allow the user to enter unavailable number of seats in the "get_time_slots" view
        if exist_number_of_seats > 0:

            # find all table with the required number of seats
            available_tables = []
            for table in tables:
                if table.number_of_seats == exist_number_of_seats:
                    available_tables.append(table)

            context = {
                "staff_member": staff_member,
                "required_number_of_seats": required_number_of_seats,
                "exist_number_of_seats": exist_number_of_seats,
                "available_tables": available_tables,
                "reservation_day": reservation_day
            }
            return render(request, 'reservation/new_reservation_available_tables.html', context)
        else:
            return reverse('new_reservation')
    else:
        return reverse('new_reservation')


# get available time slots for reservation
@login_required
def available_time_slots(request, reservation_day, table_id):

    # get user info
    staff_member = Staff_Member.objects.filter(user=request.user).first()

    # get required table
    table = Table.objects.filter(id=table_id).first()

    today = date.today()
    now = datetime.now().time()

    # get all upcoming reservation for required table
    table_reservations_for_today = Reservation.objects.filter(table=table, date__gte=today, start_time__gte=now)
    table_reservations_for_upcoming_days = Reservation.objects.filter(table=table, date__gt=today)
    table_reservations = table_reservations_for_today.union(table_reservations_for_upcoming_days)

    # get start time for each upcoming reservation for required table
    table_reservations_st = []
    for slot in table_reservations:
        table_reservations_st.append(slot.start_time)

    # get all start time for available slots
    def time_slots(start_time, end_time):
        t = start_time
        while t <= end_time:
            yield t.strftime('%H:%M:%S')
            t = (datetime.combine(date.today(), t) +
                 timedelta(minutes=15)).time()

    start_time = time(12, 00)
    end_time = time(22, 45)
    start_times_slots = []

    # delete old times slots from today's reservations
    if datetime.strptime(reservation_day, "%Y-%m-%d").date() == today:
        for slot in time_slots(start_time, end_time):
            if datetime.strptime(slot, '%H:%M:%S').time() >= now:
                start_times_slots.append(datetime.strptime(slot, '%H:%M:%S').time())
    else:
        for slot in time_slots(start_time, end_time):
            start_times_slots.append(datetime.strptime(slot, '%H:%M:%S').time())

    # get all end times for available slots
    start_time = time(12, 14)
    end_time = time(22, 59)
    end_times_slots = []
    if len(start_times_slots) > 0:
        for slot in time_slots(start_time, end_time):
            if datetime.strptime(slot, '%H:%M:%S').time() >= start_times_slots[0]:
                end_times_slots.append(datetime.strptime(slot, '%H:%M:%S').time())

    slotslist = zip(start_times_slots, end_times_slots)

    context = {
        "staff_member": staff_member,
        "table_reservations_st": table_reservations_st,
        "reservation_day": reservation_day,
        "table_id": table_id,
        "table": table,
        "slotslist": slotslist,
    }
    return render(request, 'reservation/available_time_slots.html', context)


# Create New Reservation View
class ReservationCreateView(LoginRequiredMixin, CreateView):
    model = Reservation
    fields = ['client_name', 'client_phone']

    def form_valid(self, form):
        form.instance.employee = Staff_Member.objects.filter(user=self.request.user).first()
        form.instance.start_time = self.kwargs.get("start_time")
        form.instance.end_time = self.kwargs.get("end_time")
        form.instance.date = self.kwargs.get("reservation_day")
        form.instance.table = Table.objects.filter(id=self.kwargs.get("table_id")).first()
        return super().form_valid(form)